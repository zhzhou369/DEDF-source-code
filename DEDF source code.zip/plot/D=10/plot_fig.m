clc;clear;
pool=[3,6,13,27];
for ii=1:4
   i=pool(ii);
    filepath2=strcat('./DEDF/data_Mean_',num2str(i));    
    datapath2=strcat(filepath2,'.mat');
    load(datapath2);
    plot(bestfit,'LineWidth',1.5);
    xlabel('Evolution algebra(g)');
    ylabel('Function value');
    hold on;
    
    filepath3=strcat('./LSHADE-SPACMA/data_Mean_',num2str(i));  
    datapath3=strcat(filepath3,'.mat');
    load(datapath3);
    plot(bestfit,'LineWidth',1.5);
    hold on;
    
    filepath4=strcat('./DE_rand-to-best_2/data_Mean_',num2str(i));   
    datapath4=strcat(filepath4,'.mat');
    load(datapath4);
    plot(bestfitness,'LineWidth',1.5);
    hold on;
    
    filepath5=strcat('./IADE/data_Mean_',num2str(i));   
    datapath5=strcat(filepath5,'.mat');
    load(datapath5);
    plot(bestfit,'LineWidth',1.5);
    hold on;
    legend('DEDF','LSHADE-SPACMA','DE/rand-to-best/2','IADE');
    set(gca,'FontName','Times New Roman');
end